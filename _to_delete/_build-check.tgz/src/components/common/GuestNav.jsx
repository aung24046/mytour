import { Link } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import Icon from './Icon'
import { useTourPath } from '../../lib/TourContext'

// แถบเมนูล่าง — QR ย้ายมาเป็นปุ่มวงกลม/สี่เหลี่ยมมนยกลอยกลางแถบ (สไตล์แอปเป๋าตัง)
// เก็บเป็น sub-path ล้วน — prefix /t/:code เติมตอน render ผ่าน tp()
const SIDE_ITEMS = {
  left: [
    { sub: '', key: 'home', icon: 'home', labelKey: 'guest.nav.home' },
    { sub: 'itinerary', key: 'itinerary', icon: 'map', labelKey: 'guest.nav.itinerary' },
  ],
  right: [
    { sub: 'my-room', key: 'myRoom', icon: 'bed', labelKey: 'guest.nav.myRoom' },
    // คู่มือขึ้นมาอยู่แถบล่างแทนที่นั่ง (ส.ค. 2569) — ที่นั่งย้ายไปเป็นเมนูลัดบนหน้าแรก
    // เหตุผล: หน้าแรกมีการ์ดสรุปเลขที่นั่งอยู่แล้ว ส่วนคู่มือเป็นหน้าที่เปิดซ้ำระหว่างเที่ยว
    { sub: 'trip-guide', key: 'tripGuide', icon: 'book', labelKey: 'guest.nav.tripGuide' },
  ],
}

function NavItem({ item, active, tp }) {
  const { t } = useTranslation()
  const isActive = active === item.key
  return (
    <Link
      to={tp(item.sub)}
      aria-current={isActive ? 'page' : undefined}
      className="group flex flex-1 flex-col items-center gap-0.5 px-1 pb-1.5 pt-2"
    >
      <span
        className={`flex h-9 w-full max-w-[3.25rem] items-center justify-center rounded-[10px] transition-all ${
          isActive
            ? 'scale-105 bg-brand-light text-brand-hover'
            : 'text-ink-muted opacity-80 group-hover:text-brand group-hover:opacity-100'
        }`}
      >
        <Icon name={item.icon} size={22} filled={isActive} interactive />
      </span>
      <span
        className={`text-[11px] font-semibold leading-tight ${
          isActive ? 'text-brand-hover' : 'text-ink-muted'
        }`}
      >
        {t(item.labelKey)}
      </span>
    </Link>
  )
}

export default function GuestNav({ active }) {
  const tp = useTourPath()
  const { t } = useTranslation()

  return (
    <nav
      className="no-print fixed inset-x-0 bottom-0 z-30 border-t border-line bg-surface"
      style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
      aria-label="เมนูหลัก"
    >
      <div className="mx-auto flex max-w-md items-end">
        {SIDE_ITEMS.left.map((item) => (
          <NavItem key={item.key} item={item} active={active} tp={tp} />
        ))}

        {/* ปุ่ม QR เด่นตรงกลาง */}
        <Link
          to={tp('my-qr')}
          aria-current={active === 'myQr' ? 'page' : undefined}
          className="flex flex-1 flex-col items-center"
        >
          <span className="-mt-7 flex h-[58px] w-[58px] items-center justify-center rounded-[20px] bg-brand-gradient text-white shadow-brand ring-4 ring-white transition active:scale-95">
            <Icon name="ticket" size={30} />
          </span>
          <span className="mt-0.5 pb-1.5 text-[11px] font-semibold leading-tight text-brand-hover">
            {t('guest.nav.myQr')}
          </span>
        </Link>

        {SIDE_ITEMS.right.map((item) => (
          <NavItem key={item.key} item={item} active={active} tp={tp} />
        ))}
      </div>
    </nav>
  )
}
