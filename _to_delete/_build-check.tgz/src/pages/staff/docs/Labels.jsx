// ป้ายสติกเกอร์ (ป้ายกระเป๋า / สายรัดข้อมือ) — ย้ายมาจาก /staff/print เมื่อ ส.ค. 2569
//
// เหตุผลที่ย้าย: เดิมแยกเป็นเมนู "พิมพ์และส่งออก" ต่างหากจากเมนู "เอกสาร" ทั้งที่ทำเรื่อง
// เดียวกัน (เอาข้อมูลออกมาเป็นแผ่นกระดาษ) ต่างกันแค่ขนาดกระดาษ ซึ่ง printProfiles.js
// ก็เก็บ label_50x30 ไว้กองเดียวกับ A4 อยู่แล้ว — ผู้ใช้จึงต้องจำเองว่าอะไรอยู่เมนูไหน
//
// ⚠️ ใบนี้ยังไม่ได้ใช้ DocumentShell เพราะระบบเลือกกระดาษของมันเป็นของตัวเอง
//    (ขนาดป้ายเป็นมิลลิเมตร ไม่ใช่ A4/A5) ถ้าวันหนึ่ง printProfiles รองรับป้ายเต็มรูปแบบ
//    ค่อยย้ายมาใช้เปลือกเดียวกับเอกสารใบอื่น
import { useEffect, useMemo, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { QRCodeSVG } from 'qrcode.react'

import { supabase } from '../../../lib/supabase'
import { useActiveTourId } from '../../../lib/staffSession'
import Card from '../../../components/common/Card'
import StaffHeader from '../../../components/common/StaffHeader'
import Button from '../../../components/common/Button'

const PRINT_MODES = ['luggage', 'wristband']

// ขนาด label ที่รองรับ (มม.) — 50x30 เป็น default ตามที่ระบุ, 60x40 เป็นตัวเลือกเสริม
const LABEL_SIZES = [
  { id: '50x30', widthMm: 50, heightMm: 30 },
  { id: '60x40', widthMm: 60, heightMm: 40 },
]

function csvEscape(value) {
  const str = String(value ?? '')
  if (str.includes(',') || str.includes('"') || str.includes('\n')) {
    return `"${str.replace(/"/g, '""')}"`
  }
  return str
}

function downloadCsv(filename, rows) {
  const csvContent = rows.map((row) => row.map(csvEscape).join(',')).join('\n')
  const blob = new Blob(['﻿' + csvContent], { type: 'text/csv;charset=utf-8;' })
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = filename
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
  URL.revokeObjectURL(url)
}

export default function Labels() {
  const tourId = useActiveTourId()
  const { t } = useTranslation()

  const [mode, setMode] = useState('luggage')
  const [sizeId, setSizeId] = useState('50x30')

  const [luggage, setLuggage] = useState([])
  const [guests, setGuests] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const [selectedIds, setSelectedIds] = useState(new Set())

  async function loadAll() {
    setLoading(true)
    setError(null)

    const [luggageRes, guestsRes] = await Promise.all([
      supabase
        .from('luggage')
        .select('id, tag_code, guest_id, status')
        .eq('tour_id', tourId)
        .order('created_at', { ascending: true }),
      supabase
        .from('guests')
        .select('id, name, nickname, qr_token')
        .eq('tour_id', tourId)
        .order('name'),
    ])

    if (luggageRes.error || guestsRes.error) {
      console.error('[Labels] load failed', luggageRes.error, guestsRes.error)
      setError(t('common.error'))
      setLoading(false)
      return
    }

    setLuggage(luggageRes.data ?? [])
    setGuests(guestsRes.data ?? [])
    setLoading(false)
  }

  useEffect(() => {
    loadAll()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const guestById = useMemo(() => {
    const map = {}
    for (const g of guests) map[g.id] = g
    return map
  }, [guests])

  const size = LABEL_SIZES.find((s) => s.id === sizeId) ?? LABEL_SIZES[0]

  // สร้างรายการ label ที่จะพิมพ์ ตามโหมดที่เลือก
  const labels = useMemo(() => {
    if (mode === 'luggage') {
      return luggage.map((l) => {
        const guest = guestById[l.guest_id]
        return {
          id: l.id,
          qrValue: `${window.location.origin}/bag/${l.tag_code}`,
          topText: l.tag_code,
          bottomText: guest ? guest.nickname || guest.name : t('staff.printExport.unassigned'),
        }
      })
    }
    // wristband: ใช้ qr_token เดิมของ guests ตรงๆ (ตัวเดียวกับหน้า MyQR / ที่ CheckIn สแกนเทียบ)
    return guests.map((g) => ({
      id: g.id,
      qrValue: g.qr_token,
      topText: g.nickname || g.name,
      bottomText: '',
    }))
  }, [mode, luggage, guests, guestById, t])

  useEffect(() => {
    // สลับโหมด/ขนาด แล้วเคลียร์การเลือกไว้ก่อน กันเลือกผิดชุด
    setSelectedIds(new Set())
  }, [mode])

  function toggleSelect(id) {
    setSelectedIds((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  function selectAll() {
    setSelectedIds(new Set(labels.map((l) => l.id)))
  }

  function clearSelection() {
    setSelectedIds(new Set())
  }

  const labelsToPrint = selectedIds.size > 0 ? labels.filter((l) => selectedIds.has(l.id)) : labels

  function handlePrint() {
    window.print()
  }

  function handleExportCsv() {
    const rows = [[t('staff.printExport.csvNameHeader'), t('staff.printExport.csvUrlHeader')]]
    for (const l of labelsToPrint) {
      rows.push([l.bottomText || l.topText, l.qrValue])
    }
    downloadCsv(`${mode}-labels-${sizeId}.csv`, rows)
  }

  return (
    <div className="min-h-screen bg-surface-muted print:bg-white print:p-0">
      <StaffHeader
        icon="print"
        title={t('staff.printExport.title')}
        subtitle={t('staff.printExport.subtitle')}
        backTo="/staff/documents"
      />
      {/* ตัวควบคุม — ซ่อนตอนพิมพ์ */}
      <div className="mx-auto max-w-md p-4 print:hidden">

        {loading && <p className="text-ink-muted">{t('common.loading')}</p>}
        {error && <p className="text-danger">{error}</p>}

        {!loading && !error && (
          <>
            <p className="mb-1 text-xs font-medium text-ink-faint">{t('staff.printExport.modeLabel')}</p>
            <div className="mb-3 flex gap-2">
              {PRINT_MODES.map((m) => (
                <button
                  key={m}
                  onClick={() => setMode(m)}
                  className={`flex-1 rounded-xl px-3 py-2 text-sm font-medium ${
                    mode === m ? 'bg-brand text-white' : 'bg-surface-sunken text-neutral-text'
                  }`}
                >
                  {t(`staff.printExport.mode.${m}`)}
                </button>
              ))}
            </div>

            <p className="mb-1 text-xs font-medium text-ink-faint">{t('staff.printExport.sizeLabel')}</p>
            <div className="mb-3 flex gap-2">
              {LABEL_SIZES.map((s) => (
                <button
                  key={s.id}
                  onClick={() => setSizeId(s.id)}
                  className={`flex-1 rounded-xl px-3 py-2 text-sm font-medium ${
                    sizeId === s.id ? 'bg-brand text-white' : 'bg-surface-sunken text-neutral-text'
                  }`}
                >
                  {s.widthMm}×{s.heightMm}mm
                  {s.id === '50x30' && (
                    <span className="ml-1 text-xs opacity-75">
                      ({t('staff.printExport.defaultSize')})
                    </span>
                  )}
                </button>
              ))}
            </div>

            <Card className="mb-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-ink-muted">
                  {t('staff.printExport.selectedCount', {
                    selected: selectedIds.size > 0 ? selectedIds.size : labels.length,
                    total: labels.length,
                  })}
                </span>
                <div className="flex gap-3">
                  <button onClick={selectAll} className="font-semibold text-brand">
                    {t('staff.printExport.selectAll')}
                  </button>
                  {selectedIds.size > 0 && (
                    <button onClick={clearSelection} className="font-semibold text-ink-muted">
                      {t('staff.printExport.clearSelection')}
                    </button>
                  )}
                </div>
              </div>
            </Card>

            {labels.length === 0 && (
              <p className="mb-3 text-sm text-ink-faint">{t('staff.printExport.noLabels')}</p>
            )}

            <div className="mb-3 flex flex-col gap-2">
              {labels.map((l) => (
                <button
                  key={l.id}
                  onClick={() => toggleSelect(l.id)}
                  className={`flex items-center justify-between rounded-xl border px-3 py-2 text-left text-sm ${
                    selectedIds.has(l.id) || selectedIds.size === 0
                      ? 'border-brand-light bg-brand-lighter'
                      : 'border-line bg-surface opacity-50'
                  }`}
                >
                  <span className="font-mono">{l.topText}</span>
                  <span className="text-ink-muted">{l.bottomText}</span>
                </button>
              ))}
            </div>

            <div className="flex flex-col gap-2">
              <Button onClick={handlePrint} disabled={labels.length === 0}>
                {t('staff.printExport.printButton', { count: labelsToPrint.length })}
              </Button>
              <Button variant="secondary" onClick={handleExportCsv} disabled={labels.length === 0}>
                {t('staff.printExport.exportCsvButton')}
              </Button>
            </div>

            <p className="mt-3 text-xs text-ink-faint">{t('staff.printExport.sizeLockHint')}</p>
          </>
        )}
      </div>

      {/* พื้นที่พิมพ์จริง — ซ่อนตอนดูปกติ โชว์เฉพาะตอนพิมพ์ */}
      <div className="hidden print:block">
        {labelsToPrint.map((l) => (
          <div
            key={l.id}
            className="label-page flex flex-col items-center justify-center"
            style={{ width: `${size.widthMm}mm`, height: `${size.heightMm}mm` }}
          >
            <QRCodeSVG value={l.qrValue} size={size.heightMm * 2.2} />
            <p className="label-text">{l.topText}</p>
            {l.bottomText && <p className="label-subtext">{l.bottomText}</p>}
          </div>
        ))}
      </div>

      <style>{`
        @media print {
          @page {
            size: ${size.widthMm}mm ${size.heightMm}mm;
            margin: 0;
          }
          .label-page {
            page-break-after: always;
            box-sizing: border-box;
            padding: 1mm;
          }
          .label-text {
            font-size: 2.2mm;
            font-weight: 700;
            margin-top: 0.5mm;
            text-align: center;
          }
          .label-subtext {
            font-size: 1.8mm;
            color: #333;
            text-align: center;
          }
        }
      `}</style>
    </div>
  )
}
