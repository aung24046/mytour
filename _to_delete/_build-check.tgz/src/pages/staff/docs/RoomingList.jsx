import { useEffect, useMemo, useState } from 'react'

import { supabase } from '../../../lib/supabase'
import { useActiveTourId, getStaffSession } from '../../../lib/staffSession'
import { can } from '../../../lib/permissions'
import {
  AVAILABLE_COLUMNS,
  DOC_TITLES,
  DOC_TYPES,
  formatGender,
  formatNationalId,
  formatThaiDate,
  hydrateColumns,
  useColumnFillCounts,
  useDocumentContext,
  useGuestCustomFields,
} from '../../../lib/documentData'
import { decideOrientation } from '../../../lib/printProfiles'
import { downloadXlsx, tableToSheetRows } from '../../../lib/exportXlsx'
import { sortRoomsForDisplay } from '../../../lib/roomAssign'
import DocumentHeader from '../../../components/document/DocumentHeader'
import DocumentTable from '../../../components/document/DocumentTable'
import DocumentShell, { defaultPrint } from '../../../components/document/DocumentShell'
import DocumentFooter from '../../../components/document/DocumentFooter'
import ColumnPicker from '../../../components/document/ColumnPicker'

/** คอลัมน์ที่ย้ายไปอยู่ "หัวกลุ่มของห้อง" แล้ว — ไม่พิมพ์ซ้ำเป็นคอลัมน์ */
const ROOM_KEYS = ['room_number', 'floor', 'room_type', 'max_guests', 'room_note']

// ใบจัดห้องพัก (DataSpec §1) — ส่งโรงแรมล่วงหน้า
// จัดกลุ่มตามโรงแรม แล้วเรียงตามเลขห้อง โรงแรมใหม่ขึ้นหน้าใหม่เสมอ
export default function RoomingList() {
  const tourId = useActiveTourId()
  const ctx = useDocumentContext(DOC_TYPES.ROOMING_LIST)
  const session = getStaffSession()
  const custom = useGuestCustomFields(tourId)

  const [hotels, setHotels] = useState([])
  const [rooms, setRooms] = useState([])
  const [assignments, setAssignments] = useState([])
  const [guests, setGuests] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [columns, setColumns] = useState([])
  const [presets, setPresets] = useState([])

  useEffect(() => {
    let cancelled = false

    async function load() {
      const [hotelsRes, roomsRes, assignRes, guestsRes] = await Promise.all([
        supabase
          .from('hotels')
          // ใบนี้ส่งให้โรงแรม — ต้องมีเลข booking, เบอร์ และที่อยู่ไว้ยืนยันปลายทาง
          .select(
            'id, name, check_in_date, check_out_date, check_in_time, checkout_time, address, phone, booking_ref, sort_order'
          )
          .eq('tour_id', tourId)
          .order('sort_order', { ascending: true, nullsFirst: false })
          .order('check_in_date', { ascending: true, nullsFirst: false }),
        supabase
          .from('hotel_rooms')
          .select('id, hotel_id, room_number, floor, room_type, max_guests, note'),
        supabase.from('room_assignments').select('id, room_id, guest_id'),
        supabase
          .from('guests')
          .select(
            'id, name, nickname, gender, phone, title, name_en, birthdate, national_id, passport_no, passport_expiry, nationality, note'
          )
          .eq('tour_id', tourId),
      ])

      if (cancelled) return

      if (hotelsRes.error || roomsRes.error || assignRes.error || guestsRes.error) {
        console.error('[RoomingList] load failed', hotelsRes.error, roomsRes.error, assignRes.error, guestsRes.error)
        setError('โหลดข้อมูลไม่สำเร็จ')
        setLoading(false)
        return
      }

      setHotels(hotelsRes.data ?? [])
      setRooms(roomsRes.data ?? [])
      setAssignments(assignRes.data ?? [])
      setGuests(guestsRes.data ?? [])
      setLoading(false)
    }

    load()
    return () => {
      cancelled = true
    }
  }, [tourId])

  // ตั้งคอลัมน์จาก preset ตั้งต้นครั้งแรกที่ preset โหลดเสร็จ
  useEffect(() => {
    if (ctx.presets.length === 0 || columns.length > 0) return
    setPresets(ctx.presets)
    const def = ctx.presets.find((p) => p.is_default) ?? ctx.presets[0]
    setColumns(hydrateColumns(def.columns ?? []))
  }, [ctx.presets, columns.length])

  const guestById = useMemo(() => {
    const map = {}
    for (const g of guests) map[g.id] = g
    return map
  }, [guests])

  const roomById = useMemo(() => {
    const map = {}
    for (const r of rooms) map[r.id] = r
    return map
  }, [rooms])

  // แปลงเป็นแถวพร้อมพิมพ์: 1 แถว = ผู้พัก 1 คน แต่เลขห้องแสดงเฉพาะคนแรกของห้อง
  const rowsByHotel = useMemo(() => {
    const byHotel = {}

    for (const hotel of hotels) {
      // เดิมเรียงด้วย localeCompare ตรงๆ ห้องที่ยังไม่มีเลข (สตริงว่าง) จึงลอยขึ้นบนสุดของใบ
      // ที่ส่งให้โรงแรม — ใช้ตัวเรียงกลางที่ดันห้องไม่มีเลขไปท้ายแทน
      const hotelRooms = sortRoomsForDisplay(rooms.filter((r) => r.hotel_id === hotel.id))

      const out = []
      for (const room of hotelRooms) {
        const occupants = assignments
          .filter((a) => a.room_id === room.id)
          .map((a) => guestById[a.guest_id])
          .filter(Boolean)

        // หัวกลุ่มของห้อง — ข้อมูลห้องทั้งหมดอยู่บรรทัดเดียวเต็มความกว้าง
        // เดิมวางเป็นคอลัมน์แล้วเว้นว่างในบรรทัดที่ 2 เป็นต้นไป ทำให้คนที่พักห้องเดียวกัน
        // ดูไม่ออกว่าเป็นกลุ่มเดียวกัน โดยเฉพาะตอนห้องคาบเกี่ยวหน้ากระดาษ
        const groupLabel = [
          room.room_number ? `ห้อง ${room.room_number}` : 'ห้อง (ยังไม่ระบุเลข)',
          room.floor ? `ชั้น ${room.floor}` : '',
          room.room_type ?? '',
          room.max_guests ? `พักได้ ${room.max_guests} ท่าน` : '',
          occupants.length ? `${occupants.length} ท่าน` : '',
          room.note ?? '',
        ]
          .filter(Boolean)
          .join(' · ')

        if (occupants.length === 0) {
          out.push({
            _id: `${room.id}-empty`,
            _group: groupLabel,
            name: '(ว่าง)',
          })
          continue
        }

        occupants.forEach((g, i) => {
          out.push({
            _id: `${room.id}-${g.id}`,
            _group: i === 0 ? groupLabel : undefined,
            // คงข้อมูลห้องไว้ในทุกแถวเพื่อไฟล์ Excel (ตารางพิมพ์ไม่ได้ใช้ — ดู tableColumns)
            room_number: room.room_number,
            floor: room.floor,
            room_type: `${room.room_type ?? ''}${room.max_guests ? ` · ${room.max_guests} ท่าน` : ''}`,
            room_note: room.note ?? '',
            name: g.name,
            nickname: g.nickname,
            name_en: g.name_en,
            gender: formatGender(g.gender),
            birthdate: formatThaiDate(g.birthdate),
            national_id: formatNationalId(custom.resolve(g, 'national_id')),
            passport_no: g.passport_no,
            passport_expiry: formatThaiDate(g.passport_expiry),
            nationality: g.nationality,
            phone: custom.resolve(g, 'phone'),
            note: g.note,
          })
        })
      }
      byHotel[hotel.id] = out
    }
    return byHotel
  }, [hotels, rooms, assignments, guestById, custom])

  const allRows = useMemo(() => Object.values(rowsByHotel).flat(), [rowsByHotel])

  const availableKeys = useMemo(
    () => AVAILABLE_COLUMNS.rooming_list.map((c) => c.key),
    []
  )
  const fillCounts = useColumnFillCounts(allRows, availableKeys)
  const fillCountsWithTotal = useMemo(
    () => ({ ...fillCounts, __total: allRows.length }),
    [fillCounts, allRows.length]
  )

  // ข้อมูลห้องขึ้นไปอยู่บนหัวกลุ่มแล้ว จึงไม่ต้องมีเป็นคอลัมน์ซ้ำในตาราง
  // (ยังเก็บไว้ใน `columns` เพื่อให้ ColumnPicker กับไฟล์ Excel เห็นเหมือนเดิม)
  const tableColumns = useMemo(() => columns.filter((c) => !ROOM_KEYS.includes(c.key)), [columns])

  // แนวกระดาษคำนวณจากคอลัมน์ที่พิมพ์จริง — ถ้ายังนับคอลัมน์ห้องด้วยจะสลับเป็นแนวนอนทั้งที่ไม่จำเป็น
  const orientation = useMemo(() => decideOrientation(tableColumns), [tableColumns])
  const meta = DOC_TITLES.rooming_list

  // แยกชีตต่อโรงแรม — ตรงกับที่พิมพ์ออกมาแยกหน้า
  function handleExport() {
    downloadXlsx(`ใบจัดห้องพัก-${ctx.tour?.name ?? 'tour'}`,
      hotels.map((h) => ({
        name: h.name,
        rows: tableToSheetRows(columns, rowsByHotel[h.id] ?? []),
        colWidths: columns.map((c) => (c.key === 'name' ? 28 : 18)),
      }))
    )
  }

  if (loading || ctx.loading) {
    return <p className="p-8 text-center text-ink-muted">กำลังโหลด…</p>
  }
  if (error || ctx.error) {
    return <p className="p-8 text-center text-danger">{error ?? ctx.error}</p>
  }

  return (
    <DocumentShell
      title={meta.title}
      paper={orientation.paper}
      orientationNote={orientation.switched ? orientation.reason : null}
      onPrint={defaultPrint}
      onExportXlsx={handleExport}
      printDisabled={allRows.length === 0}
      toolbar={
        <ColumnPicker
          docType={DOC_TYPES.ROOMING_LIST}
          available={AVAILABLE_COLUMNS.rooming_list}
          selected={columns}
          onChange={setColumns}
          presets={presets}
          onPresetsChange={setPresets}
          fillCounts={fillCountsWithTotal}
          canSavePreset={can(session, 'document.preset')}
        />
      }
    >
      {hotels.length === 0 && (
        <p className="py-8 text-center text-ink-muted">ทริปนี้ยังไม่ได้เพิ่มโรงแรม</p>
      )}

      {hotels.map((hotel, i) => (
        <section key={hotel.id} className={`doc-section ${i > 0 ? 'doc-page-break-before pt-6' : ''}`}>
          <DocumentHeader
            org={ctx.org}
            tour={ctx.tour}
            leader={ctx.leader}
            title={meta.title}
            subtitle={meta.subtitle}
            pageLabel={`${i + 1}/${hotels.length}`}
          />

          <div className="my-2 bg-gray-100 px-2 py-1 text-[10pt] font-medium">
            <div>
              {hotel.name}
              <span className="ml-2 font-normal text-gray-600">
                เช็คอิน {formatThaiDate(hotel.check_in_date)}
                {hotel.check_in_time && ` ${hotel.check_in_time}`} · เช็คเอาต์{' '}
                {formatThaiDate(hotel.check_out_date)}
                {hotel.checkout_time && ` ${hotel.checkout_time}`}
              </span>
            </div>
            {/* บรรทัดยืนยันปลายทาง — เลข booking + ที่อยู่/เบอร์ ให้โรงแรมตรวจสอบได้ทันที */}
            {(hotel.booking_ref || hotel.phone || hotel.address) && (
              <div className="mt-0.5 text-[8pt] font-normal text-gray-600">
                {hotel.booking_ref && <span className="mr-2">Booking: {hotel.booking_ref}</span>}
                {hotel.phone && <span className="mr-2">โทร {hotel.phone}</span>}
                {hotel.address && <span>{hotel.address}</span>}
              </div>
            )}
          </div>

          <DocumentTable
            columns={tableColumns}
            rows={rowsByHotel[hotel.id] ?? []}
            emptyText="โรงแรมนี้ยังไม่ได้จัดห้อง"
          />

          <DocumentFooter
            org={ctx.org}
            summary={`${(rowsByHotel[hotel.id] ?? []).filter((r) => r.name !== '(ว่าง)').length} ท่าน`}
          />
        </section>
      ))}
    </DocumentShell>
  )
}
