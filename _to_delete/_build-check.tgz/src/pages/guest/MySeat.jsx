import { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'

import { supabase } from '../../lib/supabase'
import { useTourId, useTourPath } from '../../lib/TourContext'
import { getGuestId } from '../../lib/guestSession'
import { saveCache, loadCache } from '../../lib/offlineCache'
import { genderBgClass } from '../../lib/genderColor'
import AnnouncementBanner from '../../components/common/AnnouncementBanner'
import Card from '../../components/common/Card'
import Button from '../../components/common/Button'
import Icon from '../../components/common/Icon'
import GuestNav from '../../components/common/GuestNav'

const CACHE_KEY = 'my_seat'

// สีพื้นของที่นั่งตามประเภท — เหมือนฝั่ง Staff: ลูกทัวร์ใช้สีตามเพศ, Staff เขียว, VIP เหลือง
function seatTypeBgClass(type, gender) {
  if (type === 'vip') return 'bg-amber-700 text-white'
  if (type === 'staff') return 'bg-emerald-700 text-white'
  return genderBgClass(gender)
}

export default function MySeat() {
  const tp = useTourPath()
  const tourId = useTourId()
  const { t } = useTranslation()
  const navigate = useNavigate()
  const guestId = getGuestId(tourId)

  const [bus, setBus] = useState(null)
  const [seats, setSeats] = useState([])
  const [guestsById, setGuestsById] = useState({})
  const [notAssigned, setNotAssigned] = useState(false)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [usingCache, setUsingCache] = useState(false)

  useEffect(() => {
    let isMounted = true

    async function loadMySeat() {
      if (!guestId) {
        setLoading(false)
        return
      }

      setLoading(true)
      setError(null)

      // 1) หาคันของฉัน — จาก bus_seats (ถ้ามีที่นั่ง) หรือจาก guests.bus_id (จับลงคันแล้วยังไม่เลือกที่นั่ง)
      const [{ data: meRow }, { data: mySeatRow }] = await Promise.all([
        supabase.from('guests').select('bus_id').eq('id', guestId).maybeSingle(),
        supabase
          .from('bus_seats')
          .select('id, bus_id, row_number, seat_position')
          .eq('tour_id', tourId)
          .eq('guest_id', guestId)
          .maybeSingle(),
      ])

      if (!isMounted) return

      const myBusId = mySeatRow?.bus_id || meRow?.bus_id || null

      if (!myBusId) {
        const cached = loadCache(CACHE_KEY)
        if (cached) {
          setBus(cached.bus)
          setSeats(cached.seats)
          setGuestsById(cached.guestsById)
          setNotAssigned(false)
          setUsingCache(true)
        } else {
          setNotAssigned(true)
        }
        setLoading(false)
        return
      }

      // 2) โหลดข้อมูลรถ + ที่นั่งทั้งคัน + รายชื่อลูกทัวร์ที่นั่งอยู่ (สำหรับระบายสีตามเพศ)
      const [busRes, seatsRes] = await Promise.all([
        supabase
          .from('buses')
          .select('id, name, license_plate, total_rows, seats_per_row')
          .eq('id', myBusId)
          .single(),
        supabase
          .from('bus_seats')
          .select('id, bus_id, row_number, seat_position, guest_id, is_available, is_seat, seat_type')
          .eq('bus_id', myBusId),
      ])

      if (!isMounted) return

      if (busRes.error || !busRes.data || seatsRes.error) {
        setError(t('common.error'))
        setLoading(false)
        return
      }

      const seatRows = seatsRes.data ?? []
      const guestIds = [...new Set(seatRows.filter((s) => s.guest_id).map((s) => s.guest_id))]

      let nextGuestsById = {}
      if (guestIds.length > 0) {
        const { data: guestsData } = await supabase
          .from('guests')
          .select('id, name, nickname, gender')
          .in('id', guestIds)
        for (const g of guestsData ?? []) nextGuestsById[g.id] = g
      }

      setBus(busRes.data)
      setSeats(seatRows)
      setGuestsById(nextGuestsById)
      setNotAssigned(false)
      setUsingCache(false)
      saveCache(CACHE_KEY, { bus: busRes.data, seats: seatRows, guestsById: nextGuestsById })
      setLoading(false)
    }

    loadMySeat()

    const channel = supabase
      .channel(`my-seat-${guestId}`)
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'bus_seats', filter: `tour_id=eq.${tourId}` },
        () => loadMySeat()
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'buses', filter: `tour_id=eq.${tourId}` },
        () => loadMySeat()
      )
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'guests', filter: `id=eq.${guestId}` },
        () => loadMySeat()
      )
      .subscribe()

    return () => {
      isMounted = false
      supabase.removeChannel(channel)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [guestId, t])

  const seatsByPosition = useMemo(() => {
    const map = {}
    for (const s of seats) map[`${s.row_number}-${s.seat_position}`] = s
    return map
  }, [seats])

  const mySeat = useMemo(
    () => seats.find((s) => s.guest_id === guestId) ?? null,
    [seats, guestId]
  )
  const mySeatLabel = mySeat ? `${mySeat.row_number}${mySeat.seat_position}` : ''

  const rows = bus ? Array.from({ length: bus.total_rows }, (_, i) => i + 1) : []
  const seatPositions = bus ? ['A', 'B', 'C', 'D'].slice(0, bus.seats_per_row) : []
  const leftPositions = seatPositions.slice(0, Math.ceil(seatPositions.length / 2))
  const rightPositions = seatPositions.slice(Math.ceil(seatPositions.length / 2))

  return (
    <div className="min-h-screen">
      <AnnouncementBanner />
      <div className="p-4 pb-28">
        <div className="mx-auto max-w-md">
          <div className="mb-4 flex items-center justify-between gap-2">
            <h1 className="flex items-center gap-2 text-2xl font-extrabold text-ink">
              <Icon name="seat" size={26} filled />
              {t('guest.mySeat.title')}
            </h1>
            {mySeatLabel ? (
              <span className="inline-flex shrink-0 items-center rounded-pill bg-brand px-3.5 py-1.5 text-sm font-semibold text-white shadow-brand">
                {t('guest.mySeat.seatPill', { seat: mySeatLabel })}
              </span>
            ) : (
              bus && (
                <span className="inline-flex shrink-0 items-center gap-1 rounded-pill bg-ink px-3.5 py-1.5 text-sm font-semibold text-white">
                  <Icon name="bus" size={15} className="text-white" />
                  {bus.name}
                </span>
              )
            )}
          </div>

          {!guestId && (
            <Card className="flex flex-col items-center gap-3 py-8 text-center">
              <p className="text-sm text-ink-muted">{t('guest.mySeat.notRegistered')}</p>
              <Button onClick={() => navigate(tp())} fullWidth={false} className="px-6">
                {t('guest.mySeat.goRegister')}
              </Button>
            </Card>
          )}

          {guestId && usingCache && (
            <p className="mb-3 rounded-control bg-warning-bg px-3 py-2 text-sm text-warning-text">
              {t('guest.mySeat.usingCache')}
            </p>
          )}

          {guestId && loading && <p className="text-ink-muted">{t('common.loading')}</p>}
          {guestId && !loading && error && <p className="text-danger">{error}</p>}

          {guestId && !loading && !error && notAssigned && (
            <Card className="flex flex-col items-center gap-2 py-8 text-center">
              <Icon name="bus" size={30} />
              <p className="text-sm text-ink-muted">{t('guest.mySeat.waitingBus')}</p>
            </Card>
          )}

          {guestId && !loading && !error && !notAssigned && bus && (
            <>
              {/* แถบข้อมูลรถ — เด่นขึ้น */}
              <div className="mb-3 flex items-center gap-3 rounded-card border border-line bg-surface p-3 shadow-card ring-1 ring-line-subtle">
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-control bg-brand-lighter text-brand-hover">
                  <Icon name="bus" size={22} />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate font-bold text-ink">{bus.name}</p>
                  <p className="mt-0.5 text-[11px] text-ink-faint">{t('guest.mySeat.licensePlate')}</p>
                </div>
                {bus.license_plate && (
                  <span className="shrink-0 rounded-control bg-surface-sunken px-2.5 py-1 font-mono text-sm font-medium tracking-wide text-ink">
                    {bus.license_plate}
                  </span>
                )}
              </div>

              {/* สถานะ 2: อยู่คันแล้ว แต่ยังไม่ได้เลือกที่นั่ง */}
              {!mySeat && (
                <div className="mb-3 flex items-center gap-3 rounded-card border border-warning/30 bg-warning-bg p-3">
                  <Icon name="location" size={22} />
                  <div className="min-w-0">
                    <p className="text-sm font-bold text-warning-text">{t('guest.mySeat.chooseOnBoard')}</p>
                    <p className="mt-0.5 text-xs text-warning-text/85">{t('guest.mySeat.chooseOnBoardHint')}</p>
                  </div>
                </div>
              )}

              {/* ผังรถ */}
              <div className="rounded-card border border-line bg-surface p-4 shadow-card ring-1 ring-line-subtle">
                {/* คำอธิบายสี */}
                <div className="mb-3 flex flex-wrap justify-center gap-x-4 gap-y-1.5 text-[11px] text-ink-muted">
                  <span className="flex items-center gap-1">
                    <span className="h-3 w-3 rounded bg-surface-sunken" /> {t('guest.mySeat.legendEmpty')}
                  </span>
                  <span className="flex items-center gap-1">
                    <span className="h-3 w-3 rounded bg-blue-600" />/
                    <span className="h-3 w-3 rounded bg-pink-600" /> {t('guest.mySeat.legendGuest')}
                  </span>
                  <span className="flex items-center gap-1">
                    <span className="h-3 w-3 rounded bg-emerald-700" /> {t('guest.mySeat.legendStaff')}
                  </span>
                  <span className="flex items-center gap-1">
                    <span className="h-3 w-3 rounded bg-amber-700" /> {t('guest.mySeat.legendVip')}
                  </span>
                  <span className="flex items-center gap-1">
                    <span className="h-3 w-3 rounded bg-brand" /> {t('guest.mySeat.yourSeat')}
                  </span>
                </div>

                {/* ตัวรถ */}
                <div className="overflow-hidden rounded-2xl border-[1.5px] border-line">
                  {/* หัวรถ */}
                  <div className="flex items-center justify-between border-b border-dashed border-line bg-surface-muted px-3 py-2">
                    <span className="flex items-center gap-1 text-[11px] text-ink-faint">
                      <Icon name="door" size={14} /> {t('guest.mySeat.doorLabel')}
                    </span>
                    <span className="flex items-center gap-1.5 text-[11px] font-semibold text-ink-muted">
                      {t('guest.mySeat.frontDriver')}
                      <Icon name="steering-wheel" size={16} className="text-brand-hover" />
                    </span>
                  </div>

                  {/* แถวที่นั่ง — ยาวถึงแถวสุดท้าย */}
                  <div className="flex flex-col gap-1.5 px-2 py-3">
                    {rows.map((rowNum) => {
                      const isMyRow = mySeat && rowNum === mySeat.row_number
                      return (
                        <div key={rowNum} className="flex items-stretch gap-2">
                          <span
                            className={`flex w-5 shrink-0 items-center justify-center text-xs ${
                              isMyRow ? 'font-semibold text-brand' : 'text-ink-faint'
                            }`}
                          >
                            {rowNum}
                          </span>
                          <div className="flex flex-1 gap-2">
                            <div className="flex flex-1 gap-1.5">
                              {leftPositions.map((pos) => {
                                const seat = seatsByPosition[`${rowNum}-${pos}`]
                                return (
                                  <MySeatBox
                                    key={pos}
                                    seat={seat}
                                    guest={guestsById[seat?.guest_id]}
                                    isMine={!!seat && seat.guest_id === guestId}
                                  />
                                )
                              })}
                            </div>
                            {rightPositions.length > 0 && <div className="w-3 shrink-0" />}
                            <div className="flex flex-1 gap-1.5">
                              {rightPositions.map((pos) => {
                                const seat = seatsByPosition[`${rowNum}-${pos}`]
                                return (
                                  <MySeatBox
                                    key={pos}
                                    seat={seat}
                                    guest={guestsById[seat?.guest_id]}
                                    isMine={!!seat && seat.guest_id === guestId}
                                  />
                                )
                              })}
                            </div>
                          </div>
                        </div>
                      )
                    })}
                  </div>

                  {/* ท้ายรถ */}
                  <div className="border-t border-dashed border-line py-1.5 text-center text-[10px] uppercase tracking-wide text-ink-faint">
                    {t('guest.mySeat.rearLabel')}
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      {/* ที่นั่งย้ายออกจากแถบล่างแล้ว (ส.ค. 2569) — ไม่มีปุ่มไหนตรง จึงไม่ไฮไลต์ */}
      <GuestNav />
    </div>
  )
}

// กล่องที่นั่งแบบอ่านอย่างเดียว (ไม่กดได้) — ที่นั่งของฉันไฮไลต์ด้วยขอบ brand หนา + ไอคอนหมุด
function MySeatBox({ seat, guest, isMine }) {
  if (!seat) {
    return <div className="h-10 flex-1 rounded-lg bg-transparent" />
  }

  if (!seat.is_seat) {
    return (
      <div className="flex h-10 min-w-0 flex-1 items-center justify-center rounded-lg bg-ink-faint/50 text-xs font-semibold text-white">
        ×
      </div>
    )
  }

  const occupied = !!seat.guest_id
  const label = occupied ? guest?.nickname || guest?.name || '?' : seat.seat_position

  return (
    <div
      title={occupied ? guest?.name || '' : ''}
      className={`relative flex h-10 min-w-0 flex-1 items-center justify-center rounded-lg px-1.5 text-xs font-semibold leading-tight transition ${
        occupied ? seatTypeBgClass(seat.seat_type, guest?.gender) : 'bg-surface-sunken text-ink-faint'
      } ${isMine ? 'ring-[3px] ring-brand ring-offset-1 scale-[1.06]' : ''}`}
    >
      {isMine && (
        <span className="absolute -top-2 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-brand text-[9px] text-white shadow-sm">
          <Icon name="location" size={10} className="text-white" />
        </span>
      )}
      <span className="w-full truncate text-center">{label}</span>
    </div>
  )
}
