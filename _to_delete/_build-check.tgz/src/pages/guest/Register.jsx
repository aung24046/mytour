import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'

import { supabase } from '../../lib/supabase'
import { useTourId } from '../../lib/TourContext'
import { getGuestId, saveGuestId, clearGuestId } from '../../lib/guestSession'
import { findFieldByPurpose, normalizePhone } from '../../lib/guestFields'
import { groupFieldsByCategory, CATEGORY_STYLE } from '../../lib/formFieldGroups'
import AnnouncementBanner from '../../components/common/AnnouncementBanner'
import Button from '../../components/common/Button'
import DynamicField from '../../components/common/DynamicField'
import BottomSheet from '../../components/common/BottomSheet'
import QrScanner from '../../components/common/QrScanner'
import Icon from '../../components/common/Icon'
import GuestNav from '../../components/common/GuestNav'
import GuestHome from '../../components/common/GuestHome'

export default function Register() {
  const tourId = useTourId()
  const { t } = useTranslation()
  const navigate = useNavigate()

  const [fields, setFields] = useState([])
  const [loadingFields, setLoadingFields] = useState(true)
  const [loadError, setLoadError] = useState(null)

  const [values, setValues] = useState({})
  const [errors, setErrors] = useState({})
  const [submitting, setSubmitting] = useState(false)
  const [submitError, setSubmitError] = useState(null)
  const [savedGuest, setSavedGuest] = useState(null)

  // เครื่องนี้เคยลงทะเบียนไว้แล้วหรือยัง — ถ้าเคย ไม่ต้องโชว์ฟอร์มเปล่าซ้ำ
  const [checkingExisting, setCheckingExisting] = useState(true)
  const [existingGuest, setExistingGuest] = useState(null)

  // กู้คืนตัวตนบนเครื่องใหม่ — ค้นด้วยเบอร์โทร หรือสแกน QR เดิม
  const [recoverySheetOpen, setRecoverySheetOpen] = useState(false)
  const [recoveryTab, setRecoveryTab] = useState('phone') // 'phone' | 'qr'
  const [phoneInput, setPhoneInput] = useState('')
  const [phoneSearching, setPhoneSearching] = useState(false)
  const [phoneMatches, setPhoneMatches] = useState(null) // null = not searched yet, [] = no match, [..] = matches
  const [phoneSearchError, setPhoneSearchError] = useState(null)
  const [qrScanError, setQrScanError] = useState(null)

  // ป้องกันลงทะเบียนซ้ำด้วยเบอร์เดิม — เจอเบอร์ซ้ำระหว่างส่งฟอร์ม ให้ถามก่อนว่าจะเข้าสู่ระบบด้วยบัญชีเดิมเลยไหม
  const [duplicateGuest, setDuplicateGuest] = useState(null)

  function restoreGuestSession(guest) {
    saveGuestId(tourId, guest.id)
    setExistingGuest(guest)
    setRecoverySheetOpen(false)
    setDuplicateGuest(null)
  }

  // หาลูกทัวร์ในทริปนี้ที่ใช้เบอร์เดียวกัน
  //
  // ⚠️ เทียบด้วยเลขล้วน ไม่ใช่สตริงดิบ — เดิมใช้ .eq() ตรงตัว ทำให้ "081-234-5678"
  // กับ "0812345678" ถือเป็นคนละเบอร์ แล้วลงทะเบียนซ้ำได้ทั้งที่เป็นคนเดียวกัน
  // Supabase ไม่มี operator เทียบแบบ normalize จึงต้องดึงมากรองฝั่ง client
  async function findGuestByPhone(phoneField, phone) {
    const target = normalizePhone(phone)
    if (!target) return null

    if (phoneField.is_core) {
      const { data, error } = await supabase
        .from('guests')
        .select(`id, name, nickname, qr_token, ${phoneField.field_key}`)
        .eq('tour_id', tourId)

      if (error) throw error
      return (data ?? []).find((g) => normalizePhone(g[phoneField.field_key]) === target) ?? null
    }

    // custom field: field_id เป็นของคลังกลางที่ใช้ร่วมหลายทริป
    // ต้องกรองด้วย tour_id ของ guest เสมอ ไม่งั้นจะไปเจอคนของทริปอื่นแล้วบล็อกผิด
    const { data: responseRows, error: responseError } = await supabase
      .from('guest_form_responses')
      .select('guest_id, value')
      .eq('field_id', phoneField.id)

    if (responseError) throw responseError

    const guestIds = (responseRows ?? [])
      .filter((r) => normalizePhone(r.value) === target)
      .map((r) => r.guest_id)

    if (guestIds.length === 0) return null

    const { data, error } = await supabase
      .from('guests')
      .select('id, name, nickname, qr_token')
      .eq('tour_id', tourId)
      .in('id', guestIds)
      .limit(1)

    if (error) throw error
    return data?.[0] ?? null
  }

  async function searchByPhone(e) {
    e.preventDefault()
    const phone = phoneInput.trim()
    if (!phone) return

    setPhoneSearching(true)
    setPhoneSearchError(null)
    setPhoneMatches(null)

    try {
      const { data: fieldsData, error: fieldsError } = await supabase
        .from('v_tour_form_fields')
        .select('id, field_key, field_purpose, is_core')
        .eq('tour_id', tourId)
        // ฟอร์มลงทะเบียนเท่านั้น — ไม่งั้นคำถามประเมินหลังทริปจะมาโผล่ตอนสมัคร
        .eq('form_type', 'registration')

      if (fieldsError) throw fieldsError

      const phoneField = findFieldByPurpose(fieldsData ?? [], 'phone')

      // เทียบด้วยเลขล้วนเหมือนตอนเช็คซ้ำ — ลูกทัวร์จำไม่ได้ว่าตอนสมัครพิมพ์มีขีดหรือไม่มี
      const target = normalizePhone(phone)

      let matches = []
      if (!phoneField || phoneField.is_core) {
        const coreKey = phoneField?.field_key || 'phone'
        const { data, error } = await supabase
          .from('guests')
          .select(`id, name, nickname, qr_token, ${coreKey}`)
          .eq('tour_id', tourId)

        if (error) throw error
        matches = (data ?? []).filter((g) => normalizePhone(g[coreKey]) === target)
      } else {
        const { data: responseRows, error: responseError } = await supabase
          .from('guest_form_responses')
          .select('guest_id, value')
          .eq('field_id', phoneField.id)

        if (responseError) throw responseError

        const guestIds = (responseRows ?? [])
          .filter((r) => normalizePhone(r.value) === target)
          .map((r) => r.guest_id)
        if (guestIds.length > 0) {
          const { data, error } = await supabase
            .from('guests')
            .select('id, name, nickname, qr_token')
            .eq('tour_id', tourId)
            .in('id', guestIds)

          if (error) throw error
          matches = data ?? []
        }
      }

      setPhoneMatches(matches)
    } catch (err) {
      console.error('[Register] phone search failed', err)
      setPhoneSearchError(t('common.error'))
    } finally {
      setPhoneSearching(false)
    }
  }

  async function handleRestoreScan(decodedText) {
    setQrScanError(null)
    const { data, error } = await supabase
      .from('guests')
      .select('id, name, nickname')
      .eq('tour_id', tourId)
      .eq('qr_token', decodedText)
      .maybeSingle()

    if (error || !data) {
      setQrScanError(t('guest.register.recoveryQrNotFound'))
      return
    }

    restoreGuestSession(data)
  }

  function handleRestoreScanError() {
    setQrScanError(t('staff.checkIn.scanCameraError'))
  }

  function openRecoverySheet() {
    setRecoveryTab('phone')
    setPhoneInput('')
    setPhoneMatches(null)
    setPhoneSearchError(null)
    setQrScanError(null)
    setRecoverySheetOpen(true)
  }

  useEffect(() => {
    let isMounted = true

    async function checkExisting() {
      const guestId = getGuestId(tourId)
      if (!guestId) {
        setCheckingExisting(false)
        return
      }

      const { data, error } = await supabase
        .from('guests')
        .select('id, name, nickname')
        .eq('id', guestId)
        .maybeSingle()

      if (!isMounted) return

      if (error || !data) {
        // guest_id ในเครื่องไม่ตรงกับข้อมูลจริงแล้ว (เช่นถูกลบไปฝั่ง staff) — เคลียร์แล้วให้ลงทะเบียนใหม่
        clearGuestId(tourId)
      } else {
        setExistingGuest(data)
      }
      setCheckingExisting(false)
    }

    checkExisting()
    return () => {
      isMounted = false
    }
  }, [])

  useEffect(() => {
    let isMounted = true

    async function loadFields() {
      setLoadingFields(true)
      setLoadError(null)

      const { data, error } = await supabase
        .from('v_tour_form_fields')
        .select('id, field_key, label, field_type, options, is_required, is_core, sort_order, category')
        .eq('tour_id', tourId)
        .eq('form_type', 'registration')
        .eq('is_active', true)
        .order('sort_order', { ascending: true })

      if (!isMounted) return

      if (error) {
        console.error('[Register] load form_fields failed', error)
        setLoadError(t('common.error'))
      } else {
        setFields(data ?? [])
        // checkbox fields need an array default
        const initial = {}
        for (const f of data ?? []) {
          initial[f.id] = f.field_type === 'checkbox' ? [] : ''
        }
        setValues(initial)
      }
      setLoadingFields(false)
    }

    loadFields()
    return () => {
      isMounted = false
    }
  }, [t])

  function setFieldValue(fieldId, value) {
    setValues((prev) => ({ ...prev, [fieldId]: value }))
    setErrors((prev) => ({ ...prev, [fieldId]: undefined }))
  }

  function validate() {
    const nextErrors = {}
    for (const f of fields) {
      const v = values[f.id]
      const isEmpty = f.field_type === 'checkbox' ? !v || v.length === 0 : !v || !String(v).trim()
      if (f.is_required && isEmpty) {
        nextErrors[f.id] = t('guest.register.requiredField')
      }
    }
    setErrors(nextErrors)
    return Object.keys(nextErrors).length === 0
  }

  async function handleSubmit(e) {
    e.preventDefault()
    setSubmitError(null)
    if (!validate()) return

    setSubmitting(true)
    try {
      // เช็คเบอร์ซ้ำก่อนสร้างลูกทัวร์ใหม่ — เจอเบอร์เดิมในทริปนี้แล้วให้ถามก่อนว่าจะเข้าสู่ระบบด้วยบัญชีเดิมเลยไหม
      const phoneField = findFieldByPurpose(fields, 'phone')
      const phoneValue = phoneField ? (values[phoneField.id] ?? '').toString().trim() : ''

      if (phoneField && phoneValue) {
        const existing = await findGuestByPhone(phoneField, phoneValue)
        if (existing) {
          setDuplicateGuest(existing)
          setSubmitting(false)
          return
        }
      }

      // Core fields go straight onto the guests row; custom fields go to guest_form_responses.
      const corePayload = { tour_id: tourId }
      const customAnswers = []

      for (const f of fields) {
        const raw = values[f.id]
        const value = f.field_type === 'checkbox' ? raw ?? [] : (raw ?? '').toString().trim()

        if (f.is_core) {
          corePayload[f.field_key] = f.field_type === 'checkbox' ? value.join(', ') : value || null
        } else {
          const stringValue = f.field_type === 'checkbox' ? value.join(', ') : value
          if (stringValue) {
            customAnswers.push({ field_id: f.id, value: stringValue })
          }
        }
      }

      const { data: guest, error: guestError } = await supabase
        .from('guests')
        .insert(corePayload)
        .select('id, qr_token')
        .single()

      // ชนกับ unique index guests_unique_phone_per_tour_idx = มีคนใช้เบอร์นี้ในทริปนี้แล้ว
      // เกิดได้แม้ผ่านการเช็คด้านบน เช่นกดส่งรัวสองครั้ง หรือเปิดสองแท็บพร้อมกัน
      if (guestError?.code === '23505' && guestError.message?.includes('phone')) {
        const existing = phoneField ? await findGuestByPhone(phoneField, phoneValue) : null
        if (existing) {
          setDuplicateGuest(existing)
          setSubmitting(false)
          return
        }
        setSubmitError(t('guest.register.duplicatePhone'))
        setSubmitting(false)
        return
      }
      if (guestError) throw guestError

      if (customAnswers.length > 0) {
        const { error: responsesError } = await supabase
          .from('guest_form_responses')
          .insert(customAnswers.map((a) => ({ ...a, guest_id: guest.id })))

        if (responsesError) throw responsesError
      }

      saveGuestId(tourId, guest.id)
      setSavedGuest(guest)
    } catch (err) {
      console.error('[Register] submit failed', err)
      setSubmitError(err.message ?? t('common.error'))
    } finally {
      setSubmitting(false)
    }
  }

  if (savedGuest || existingGuest) {
    const guestForDisplay = savedGuest || existingGuest

    return (
      <div className="min-h-screen">
        <div className="p-4 pb-28">
          <div className="mx-auto max-w-md">
            <GuestHome guest={guestForDisplay} isNew={!!savedGuest} />
          </div>
        </div>

        <GuestNav active="home" />
      </div>
    )
  }

  if (checkingExisting) {
    return (
      <div className="min-h-screen bg-surface-muted">
        <AnnouncementBanner />
        <div className="p-4">
          <p className="text-ink-muted">{t('common.loading')}</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen">
      <AnnouncementBanner />
      <div className="p-4">
        <div className="mx-auto max-w-md">
          <div className="mb-5 mt-2 flex flex-col items-center text-center">
            <div className="mb-3 flex h-16 w-16 items-center justify-center rounded-[18px] bg-brand-gradient text-white shadow-brand">
              <Icon name="compass" size={30} />
            </div>
            <h1 className="text-2xl font-extrabold text-ink">
              {t('guest.register.title')}
            </h1>
            <p className="mt-2 flex items-center gap-1.5 text-sm text-ink-muted">
              <Icon name="lock" size={13} />
              {t('guest.register.subtitle')}
            </p>
          </div>

          {loadingFields && <p className="text-ink-muted">{t('common.loading')}</p>}
          {loadError && <p className="text-danger">{loadError}</p>}

          {!loadingFields && !loadError && (
            <form onSubmit={handleSubmit} className="flex flex-col gap-3.5">
              {groupFieldsByCategory(fields).map(({ category, fields: groupFields }) => {
                const st = CATEGORY_STYLE[category] || CATEGORY_STYLE.other
                return (
                  <div key={category} className="overflow-hidden rounded-2xl border border-neutral-bg bg-surface shadow-card">
                    <div className="flex items-center gap-2 px-4 py-2.5" style={{ background: st.tint }}>
                      <Icon name={st.icon} size={18} color={st.iconColor} />
                      <span className="text-sm font-bold" style={{ color: st.text }}>
                        {t(`guest.register.category.${category}`)}
                      </span>
                    </div>
                    <div className="flex flex-col gap-4 p-4">
                      {groupFields.map((f) => (
                        <DynamicField
                          key={f.id}
                          field={f}
                          value={values[f.id]}
                          onChange={(v) => setFieldValue(f.id, v)}
                          error={errors[f.id]}
                        />
                      ))}
                    </div>
                  </div>
                )
              })}

              {submitError && <p className="text-sm text-danger">{submitError}</p>}

              <Button type="submit" disabled={submitting}>
                {submitting ? t('guest.register.submitting') : t('guest.register.submit')}
              </Button>
            </form>
          )}

          <button
            onClick={openRecoverySheet}
            className="mt-4 w-full text-center text-sm font-semibold text-brand underline decoration-brand-light underline-offset-2 hover:text-brand-hover"
          >
            {t('guest.register.alreadyRegisteredLink')}
          </button>
        </div>
      </div>

      <BottomSheet
        open={recoverySheetOpen}
        onClose={() => setRecoverySheetOpen(false)}
        title={t('guest.register.recoveryTitle')}
      >
        <div className="mb-3 flex gap-2">
          <button
            onClick={() => setRecoveryTab('phone')}
            className={`flex-1 rounded-control px-3 py-2 text-sm font-semibold transition ${
              recoveryTab === 'phone' ? 'bg-brand-gradient text-white shadow-brand' : 'bg-surface-sunken text-neutral-text'
            }`}
          >
            {t('guest.register.recoveryByPhone')}
          </button>
          <button
            onClick={() => setRecoveryTab('qr')}
            className={`flex-1 rounded-control px-3 py-2 text-sm font-semibold transition ${
              recoveryTab === 'qr' ? 'bg-brand-gradient text-white shadow-brand' : 'bg-surface-sunken text-neutral-text'
            }`}
          >
            {t('guest.register.recoveryByQr')}
          </button>
        </div>

        {recoveryTab === 'phone' && (
          <div>
            <form onSubmit={searchByPhone} className="flex gap-2">
              <input
                type="tel"
                value={phoneInput}
                onChange={(e) => setPhoneInput(e.target.value)}
                placeholder={t('guest.register.phonePlaceholder')}
                className="min-w-0 flex-1 rounded-control border border-transparent bg-surface-sunken px-3.5 py-3 text-base text-ink shadow-inner focus:border-brand focus:bg-surface focus:outline-none focus:ring-4 focus:ring-brand-light/70 transition"
              />
              <Button type="submit" disabled={phoneSearching} fullWidth={false} className="shrink-0 px-4">
                {t('common.search')}
              </Button>
            </form>

            {phoneSearching && <p className="mt-3 text-sm text-ink-muted">{t('common.loading')}</p>}
            {phoneSearchError && <p className="mt-3 text-sm text-danger">{phoneSearchError}</p>}

            {phoneMatches && phoneMatches.length === 0 && (
              <p className="mt-3 text-sm text-ink-muted">{t('guest.register.recoveryNoMatch')}</p>
            )}

            {phoneMatches && phoneMatches.length > 0 && (
              <div className="mt-3 flex flex-col gap-2">
                <p className="text-sm text-ink-muted">{t('guest.register.recoverySelectYou')}</p>
                {phoneMatches.map((g) => (
                  <button
                    key={g.id}
                    onClick={() => restoreGuestSession(g)}
                    className="rounded-xl border border-line px-3 py-2.5 text-left text-sm font-medium text-ink hover:bg-surface-muted"
                  >
                    {g.nickname || g.name}
                    {g.nickname && <span className="ml-1 text-ink-faint">({g.name})</span>}
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {recoveryTab === 'qr' && (
          <div>
            <QrScanner onScan={handleRestoreScan} onError={handleRestoreScanError} />
            <p className="mt-3 text-center text-sm text-ink-muted">
              {t('guest.register.recoveryQrHint')}
            </p>
            {qrScanError && (
              <p className="mt-2 text-center text-sm text-danger">{qrScanError}</p>
            )}
          </div>
        )}

        <Button
          variant="secondary"
          className="mt-3"
          onClick={() => setRecoverySheetOpen(false)}
        >
          {t('common.cancel')}
        </Button>
      </BottomSheet>

      <BottomSheet
        open={!!duplicateGuest}
        onClose={() => setDuplicateGuest(null)}
        title={t('guest.register.duplicatePhoneTitle')}
      >
        <p className="text-sm text-ink-muted">
          {t('guest.register.duplicatePhoneMessage', {
            name: duplicateGuest?.nickname || duplicateGuest?.name,
          })}
        </p>

        <Button className="mt-4" onClick={() => restoreGuestSession(duplicateGuest)}>
          {t('guest.register.duplicatePhoneConfirm')}
        </Button>
        <Button variant="secondary" className="mt-2" onClick={() => setDuplicateGuest(null)}>
          {t('guest.register.duplicatePhoneCancel')}
        </Button>
      </BottomSheet>
    </div>
  )
}
